package Assignment1;

import org.junit.Assert;
import org.junit.Test;

/*
 * Filename: CarRegistrationTest2.Java
 * Student: Dan Blais 040826486
 * Course: CST8284 301 OOP
 * Assignment: Assignment 01
 * Date: February 18, 2024
 * Professor: Professor George Kriger
 * Purpose: Learn how to use inheritance and the extends keyword.
 * Classlist: CarRegistration.java, CarRegistrationTest.java, CarSelection.java, CarRegistrationTest2.java
 */

/**
 * This class serves as a Junit test class for the CarRegistration class. This class
 * will provide methods to test 3 of the main methods of the CarRegistration class.
 * The first test method will test the getCustomerAge() method of the CarRegistration class.
 * It uses an assertEquals assertion and assumes that the expected value should match the
 * actual value. The second test method tests the isPreapproved() method of the CarRegistration
 * class. This test method uses an assertEquals assertion and assumes that the expected
 * value will match the actual value. The final test tests the isEligibleToDrive() method of
 * the CarRegistration class. This method uses an assertEquals assertion and assumes that the
 * actual value will match the expected value.
 * @author Dan Blais
 * @see CarRegistration
 * @version JDK 21
 */
public class CarRegistrationTest2 {

    /**
     * This test method will test the getCustomerAge() method of the CarRegistration class
     * using an assertEquals call.
     */
    @Test
    public void getCustomerAge() {
        CarRegistration carRegistration = new CarRegistration(5000, 1, 500, "Dan", "Blais", "Male", 1997, 80000);
        int actual = carRegistration.getCustomerAge();
        int expected = 27;
        Assert.assertEquals(expected, actual);
    }

    /**
     * This test method will test the isPreapproved() method of the CarRegistration class
     * using an assertEquals call. Test is for a return of true.
     */
    @Test
    public void isPreapprovedTrue() {
        CarRegistration carRegistration = new CarRegistration(5000, 1, 500, "Dan", "Blais", "Male", 1997, 80000);
        boolean actual = carRegistration.isPreapproved();
        boolean expected = true;
        Assert.assertEquals(expected, actual);
    }

    /**
     * This test method will test the isPreapproved() method of the CarRegistration class
     * using an assertEquals call. Test is for a return of false.
     */
    @Test
    public void isPreapprovedFalse() {
        CarRegistration carRegistration = new CarRegistration(25000, 1, 500, "Dan", "Blais", "Male", 1997, 80000);
        boolean actual = carRegistration.isPreapproved();
        boolean expected = false;
        Assert.assertEquals(expected, actual);
    }

    /**
     * This test method will test the isEligibleToDrive() method of the CarRegistration class
     * using an assertEquals call.
     */
    @Test
    public void isEligibleToDriveTrue() {
        CarRegistration carRegistration = new CarRegistration(5000, 1, 500, "Dan", "Blais", "Male", 1997, 80000);
        carRegistration.getCustomerAge();
        boolean actual = carRegistration.isEligibleToDrive();
        boolean expected = true;
        Assert.assertEquals(expected, actual);
    }
}