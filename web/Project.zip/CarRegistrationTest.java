package Assignment1;

import java.util.Scanner;

/*
 * Filename: CarRegistrationTest.Java
 * Student: Dan Blais 040826486
 * Course: CST8284 301 OOP
 * Assignment: Assignment 01
 * Date: February 18, 2024
 * Professor: Professor George Kriger
 * Purpose: Learn how to use inheritance and the extends keyword.
 * Classlist: CarRegistration.java, CarRegistrationTest.java, CarSelection.java, CarRegistrationTest2.java
 */

/**
 * This class serves as a test class to test the CarRegistration and CarSelection classes.
 * The main method within this class will prompt for and store user input and several variables.
 * It will then Instantiate a new instance of the CarRegistration class passing the values of
 * the aforementioned variables to the constructor. Finally, the relevant data about the customer
 * and CarRegistration object are formatted and printed to the console. This is done using
 * String manipulation and a for loop to iterate through a String array created by the
 * retrieveCustomerInfo() method of the CarRegistration class.
 * @author Dan Blais
 * @see CarRegistration
 * @see CarSelection
 * @version JDK 21
 */
public class CarRegistrationTest {

    /**
     * The main method which drives the program.
     * @param args String array that represents command line arguments supplied by the user. Not used in this program.
     */
    public static void main(String[] args) {
        Scanner user = new Scanner(System.in);
        String first, last, gender;
        int birthYear;
        double yearlyIncome, basePrice, upgradeCoefficient, colorIndex;

        System.out.printf("Enter First Name: ");
        first = user.nextLine();
        System.out.printf("Enter Last Name: ");
        last = user.nextLine();
        System.out.printf("Enter Gender: ");
        gender = user.nextLine();
        System.out.printf("Enter Birth Year: ");
        birthYear = user.nextInt();
        System.out.printf("Enter Yearly Income: ");
        yearlyIncome = user.nextDouble();
        System.out.printf("Enter Base Price: ");
        basePrice = user.nextDouble();
        System.out.printf("Enter Upgrade Coefficient (1/2): ");
        upgradeCoefficient = user.nextDouble();
        System.out.printf("Enter Color Cost (0-5000): ");
        colorIndex = user.nextDouble();

        CarRegistration userFirst = new CarRegistration(basePrice, upgradeCoefficient, colorIndex, first, last, gender, birthYear, yearlyIncome);
        for(int i = 0; i < userFirst.retrieveCustomerInfo().length; i++)
            System.out.printf("%s%n", userFirst.retrieveCustomerInfo()[i]);
    }
}
