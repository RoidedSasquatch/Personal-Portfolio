package Assignment1;

/*
 * Filename: CarRegistration.Java
 * Student: Dan Blais 040826486
 * Course: CST8284 301 OOP
 * Assignment: Assignment 01
 * Date: February 18, 2024
 * Professor: Professor George Kriger
 * Purpose: Learn how to use inheritance and the extends keyword.
 * Classlist: CarRegistration.java, CarRegistrationTest.java, CarSelection.java, CarRegistrationTest2.java
 */

/**
 * This class is a subclass of the CarSelection superclass. This class represents the information required to price and register the car model.
 * It contains variables that are characteristic of a CarRegistraation object including the
 * basePrice, upgradeCoefficient (1 for no upgrade or 2 for upgraded) and colorIndex(Value of
 * any custom painting). It also contains variables which will store data relating to
 * a customer that would be associated with a CarRegistration. These include first name,
 * last name, gender, birth year, age, and yearlyIncome. The age variable's data will be calculated by
 * a method contained within this class (getCustomerAge()). Finally, a constant representing
 * the current year is included. Several methods also exist within this class.
 * These methods will perform checks to determine eligibility to drive and buy
 * a car, accessors and mutators, as well as a function to create a String array containing
 * the relevant customer data.
 * @author Dan Blais
 * @see CarSelection
 * @see CarRegistrationTest
 * @see CarRegistrationTest2
 * @version JDK 21
 */
public class CarRegistration extends CarSelection {
    private double basePrice; // base price of the car
    private double upgradeCoefficient; // value range: 1(no upgrade) to 2 (highest level upgrade)
    private double colorIndex; // value range: 0 (default color) to 5000
    private String firstName; // first name of the customer
    private String lastName; // last name of the customer
    private String gender; // gender of the customer
    private int birthYear; // birth year of the customer
    private double yearlyIncome; // yearly income of the customer
    private int customerAge; // age of the customer

    /**
     * Constant used to represent the current year 2024.
     */
    public static final int CURRENT_YEAR = 2024;

    /**
     * Constructor to instantiate a car registration object of the class
     * @param firstName The customer's first name.
     * @param lastName The customer's last name.
     * @param gender The customer's gender.
     * @param birthYear The customer's birthYear.
     * @param yearlyIncome The customer's yearly income.
     * @param basePrice The base price of the car.
     * @param upgradeCoefficient The upgrade coefficient of the car.
     * @param colorIndex The color index of the car.
     */
    public CarRegistration(double basePrice, double upgradeCoefficient,
                           double colorIndex, String firstName, String lastName, String gender, int birthYear,
                           double yearlyIncome) {
        super();
        this.basePrice = basePrice;
        this.upgradeCoefficient = upgradeCoefficient;
        this.colorIndex = colorIndex;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthYear = birthYear;
        this.gender = gender;
        this.yearlyIncome = yearlyIncome;
    }//constructor

    /**
     * Accessor for the basePrice variable.
     * @return The value of the basePrice variable.
     */
    public double getBasePrice() {
        return basePrice;
    }

    /**
     * Mutator for the basePrice variable.
     * @param basePrice The base price of the car.
     */
    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }

    /**
     * Accessor for the upgradeCoefficient variable.
     * @return The value of the upgradeCoefficient variable.
     */
    public double getUpgradeCoefficient() {
        return upgradeCoefficient;
    }

    /**
     * Mutator for the upgradeCoefficient variable.
     * @param upgradeCoefficient The dealer mark-up for the car.
     */
    public void setUpgradeCoefficient(double upgradeCoefficient) {
        this.upgradeCoefficient = upgradeCoefficient;
    }

    /**
     * Accessor for the colorIndex variable.
     * @return The value of the colorIndex variable.
     */
    public double getColorIndex() {
        return colorIndex;
    }

    /**
     * Mutator for the colorIndex variable.
     * @param colorIndex The price of any paint addons for the car.
     */
    public void setColorIndex(double colorIndex) {
        this.colorIndex = colorIndex;
    }

    /**
     * Accessor for the firstName variable.
     * @return The value of the firstName variable.
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for the firstName variable.
     * @param firstName The first name of the customer.
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Accessor for the lastName variable.
     * @return The value of the lastName variable.
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Mutator for the lastName variable.
     * @param lastName The last name of the customer.
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Accessor for the gender variable.
     * @return The value of the gender variable.
     */
    public String getGender() {
        return gender;
    }

    /**
     * Mutator for the basePrice variable.
     * @param gender The gender of the customer.
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * Accessor for the birthYear variable.
     * @return The value of the birthYear variable.
     */
    public int getBirthYear() {
        return birthYear;
    }

    /**
     * Mutator for the birthYear variable.
     * @param birthYear The birth year of the customer.
     */
    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    /**
     * Accessor for the yearlyIncome variable.
     * @return The value of the yearlyIncome variable.
     */
    public double getYearlyIncome() {
        return yearlyIncome;
    }

    /**
     * Mutator for the basePrice variable.
     * @param yearlyIncome The annual income of the customer.
     */
    public void setYearlyIncome(double yearlyIncome) {
        this.yearlyIncome = yearlyIncome;
    }

    /**
     * This method calculates a customer's age. This is calculated by
     * subtracting the variable birthYear from the variable CURRENT_YEAR.
     * @return The current age of the customer.
     */
    public int getCustomerAge() {
        customerAge = CURRENT_YEAR - birthYear;
        return customerAge;
    }


    /**
     * This function checks whether a customer is eligible to purchase the car
     * and prints out a message about it.
     * @return True if the car price is less than 20% of the customer's income. Return false if the price is more than 20%.
     */
    public boolean isPreapproved() {
        return !(calculateCarPrice(basePrice, upgradeCoefficient, colorIndex) > (yearlyIncome * 0.20));
    }

    /**
     * This function check if a customer is eligible to drive and prints a relevant message.
     * A customer should be at least 16 years old to drive, therefore this function
     * will return true if customerAge is >= 16.
     * @return True if the customerAge variable is >= 16, returns False if under 16.
     */
    public boolean isEligibleToDrive(){
        return customerAge >= 16;
    }

    /**
     * This function obtains the customer’s information. It will call the
     * isEligibleToDrive() and isPreapproved() methods and
     * will set the eligibleToDrive variable to an eligible message upon returning
     * true, or an ineligible to drive message if false. The same check is performed
     * for the eligibleToDrive variable. The function will then return a String array
     * containing the first name, last name, gender, Age, Birth Year, eligibility to drive
     * and eligibility to buy a car.
     * @return A String array containing firstName, lastName, gender, customerAge, birthYear, eligibleToDrive, eligibleToBuy.
     */
    public String[] retrieveCustomerInfo() {
        String eligibleToDrive, eligibleToBuy;
        if(isEligibleToDrive())
            eligibleToDrive = "Customer is eligible to drive";
        else
            eligibleToDrive = "Customer is ineligible to drive";
        if(isPreapproved())
            eligibleToBuy = "Customer is pre-approved for purchase.";
        else
            eligibleToBuy = "Customer is not pre-approved for purchase";
        return new String[] {"First Name: " + firstName, "Last Name: " + lastName, "Gender: " + gender, "Age: " + getCustomerAge(), "Birth Year: " + birthYear, eligibleToDrive, eligibleToBuy};
    }
}//class