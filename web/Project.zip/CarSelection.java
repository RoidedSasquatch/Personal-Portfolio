package Assignment1;

/*
 * Filename: CarSelection.Java
 * Student: Dan Blais 040826486 (Supplied as part of lab).
 * Course: CST8284 301 OOP
 * Assignment: Assignment 01
 * Date: February 18, 2024
 * Professor: Professor George Kriger
 * Purpose: Learn how to use inheritance and the extends keyword.
 * Classlist: CarRegistration.java, CarRegistrationTest.java, CarSelection.java, CarRegistrationTest2.java
 */

/**
 * Assignment1.CarSelection is a base class to be extended for a vehicle purchase
 * process, which is also named as Assignment 1. It contains a method to calculate
 * a vehicle price based on the base price of the car, the dealer mark-up, and the price
 * of any additional color add-ons.
 *
 * @author Moshiur Rahman
 * @see CarRegistration
 * @see CarRegistrationTest
 * @version JDK 21
 */

public class CarSelection {
    /**
     * This method returns the price of a vehicle of a particular model based on
     * its base price, upgrade coefficient and color choice.
     * @param basePrice base price for the particular model
     * @param upgradeCoefficient dealer markup
     * @param colorIndex addition for premium color
     * @return total model price including all markup and premium prices
     */
    public double calculateCarPrice(double basePrice, double upgradeCoefficient, double colorIndex) {
        return basePrice * upgradeCoefficient + colorIndex;
    }
}
